# Laboratory 1

If you want to run it make sure you have nodejs installed then:
- run `npm i` in the directory
- run the program either with `./index.js -k 4 -s lapte1234` if you have node installed according to the docs